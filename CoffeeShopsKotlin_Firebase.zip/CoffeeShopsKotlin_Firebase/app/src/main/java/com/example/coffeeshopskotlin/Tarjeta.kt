package com.example.coffeeshopskotlin

class Tarjeta(val imag: ByteArray, val titulo: String, val subtit: String) {}