package com.example.coffeeshops_fragments

class Coffee(val title: String, val subtitle: String, val image: Int)