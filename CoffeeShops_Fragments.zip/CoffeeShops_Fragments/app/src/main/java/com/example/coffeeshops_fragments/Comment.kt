package com.example.coffeeshops_fragments

class Comment(val comm1: String)